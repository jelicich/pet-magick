  <div class="content-format-quote">
    <?php the_content(); ?>
  </div>

