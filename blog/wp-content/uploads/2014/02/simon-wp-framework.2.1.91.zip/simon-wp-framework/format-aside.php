
<div class="content-format-aside">
  <div class="post-format-icon"></div>
  <?php the_content(); ?>
</div>
