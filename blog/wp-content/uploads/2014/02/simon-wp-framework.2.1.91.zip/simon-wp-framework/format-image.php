
<div class="content-format-image">
  <div class="post-format-icon"></div>
  <?php the_content(); ?>
</div>
