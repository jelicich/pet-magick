
<div class="content-format-video">
  <div class="post-format-icon"></div>
  <?php the_content(); ?>
</div>
