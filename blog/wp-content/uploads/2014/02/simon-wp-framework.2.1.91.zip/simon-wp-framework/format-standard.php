<div class="content-format-standard">
  <div class="post-format-icon"></div>
  <?php the_content(); ?>
</div>