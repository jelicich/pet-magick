<div class="content-format-chat">
  <div class="post-format-icon"></div>
  <?php the_content(); ?>
</div>