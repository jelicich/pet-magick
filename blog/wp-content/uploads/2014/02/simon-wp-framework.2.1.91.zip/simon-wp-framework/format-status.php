
<div class="content-format-status">
  <div class="post-format-icon"></div>
  <?php the_content(); ?>
</div>
